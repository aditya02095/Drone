#include <stdio.h>
#include <stdbool.h>
#include <esp_task.h>
#include "mpu6050.h"
#include "motor.h"
#include "pid.h"
#include "receiver.h"
#include "driver/i2c_master.h"
#include "esp_err.h"

#define I2C_SCL_IO      22
#define I2C_SDA_IO      21
#define I2C_PORT        0
#define I2C_FREQ_HZ     100000

pid_t roll_pid;
pid_t pitch_pid;
pid_t yaw_pid;

i2c_master_bus_handle_t bus_handle = NULL;
i2c_master_dev_handle_t dev_handle = NULL;

void i2c_master_init(void)
{
    i2c_master_bus_config_t bus_config = {
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .i2c_port = I2C_PORT,
        .scl_io_num = I2C_SCL_IO,
        .sda_io_num = I2C_SDA_IO,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &bus_handle));
}

void i2c_add_device(void)
{
    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = MPU_ADDR,
        .scl_speed_hz = I2C_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus_handle, &dev_cfg, &dev_handle));
}

void app_main(void)
{
    int16_t gx, gy, gz;
	uint16_t roll, pitch, throttle, yaw, aux1, aux2;
	
    i2c_master_init();
    i2c_add_device();
	ESP_ERROR_CHECK(mpu_init(dev_handle));
	ESP_ERROR_CHECK(receiver_init());
	pid_init(&roll_pid,
	         1.0f,
	         0.0f,
	         0.1f,
	         -500,
	         500);

	pid_init(&pitch_pid,
	         1.0f,
	         0.0f,
	         0.1f,
	         -500,
	         500);

	pid_init(&yaw_pid,
	         1.0f,
	         0.0f,
	         0.1f,
	         -500,
	         500);
	motor_init();
	
	while (1)
	{
	    if (receiver_update() == ESP_OK)
	    {
	        roll = receiver_get_roll();
	        pitch = receiver_get_pitch();
	        throttle = receiver_get_throttle();
	        yaw = receiver_get_yaw();
	        aux1 = receiver_get_aux1();
	        aux2 = receiver_get_aux2();
	    }

	    ESP_ERROR_CHECK(mpu_read_gyro(&gx, &gy, &gz));

	    /* Receiver commands */
	    float desired_roll_rate =
	        ((float)roll - 1500.0f) / 500.0f * 200.0f;

	    float desired_pitch_rate =
	        ((float)pitch - 1500.0f) / 500.0f * 200.0f;

	    float desired_yaw_rate =
	        ((float)yaw - 1500.0f) / 500.0f * 200.0f;

	    /* MPU6050 default sensitivity:
	       ±250 dps = 131 LSB/(°/s)
	    */
	    float measured_roll_rate = gx / 131.0f;
	    float measured_pitch_rate = gy / 131.0f;
	    float measured_yaw_rate = gz / 131.0f;

	    float dt = 0.001f;

	    float roll_pid_out =
	        pid_update(
	            &roll_pid,
	            desired_roll_rate,
	            measured_roll_rate,
	            dt);

	    float pitch_pid_out =
	        pid_update(
	            &pitch_pid,
	            desired_pitch_rate,
	            measured_pitch_rate,
	            dt);

	    float yaw_pid_out =
	        pid_update(
	            &yaw_pid,
	            desired_yaw_rate,
	            measured_yaw_rate,
	            dt);

	    /* Mixer will be added later */

	    vTaskDelay(pdMS_TO_TICKS(1));
	}
}
